<?php
if(isset($_POST["submit"]))
{
 $heading=$_POST["heading"];

 require_once '../include/db.php';
 require_once '../include/functions.php';
 session_start();

 $ID=$_SESSION["userid"];

 if(empty($heading) !== false)
 {
  header("Location: ../pages/deleteNote.php?error=emptyInput");
  exit();
 }
 if(invalidHeading($heading) !== false)
 {
  header("Location: ../pages/deleteNote.php?error=invalidHeading");
  exit();
 }
 if(headingExists($connection,$heading) === false)
 {
  header("Location: ../pages/deleteNote.php?error=headingDoesNotExist");
  exit();
 }
 deleteNote($connection,$ID,$heading,$text);
 header("Location: ../pages/deleteNote.php?error=none");
 exit();
}
?>
