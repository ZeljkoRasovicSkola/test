<?php
if(isset($_POST["submit"]))
{
 $email=$_POST["email"];
 $name=$_POST["name"];
 $pass=$_POST["pass"];
 $passRepeat=$_POST["passRepeat"];

 require_once '../include/db.php';
 require_once '../include/functions.php';

 if(emptyInputSignup($email,$name,$pass,$passRepeat) !== false)
 {
  header("Location: ../pages/signup.php?error=emptyInput");
  exit();
 }
 if(invalidEmail($email) !== false)
 {
  header("Location: ../pages/signup.php?error=invalidEmail");
  exit();
 }
 if(invalidUsername($name) !== false)
 {
  header("Location: ../pages/signup.php?error=invalidUsername");
  exit();
 }
 if(passMatch($pass,$passRepeat) !== false)
 {
  header("Location: ../pages/signup.php?error=passwordsDoNotMatch");
  exit();
 }
 if(nameExists($connection,$name) !== false)
 {
  header("Location: ../pages/signup.php?error=usernameTaken");
  exit();
 }
 if(emailExists($connection,$email) !== false)
 {
  header("Location: ../pages/signup.php?error=emailTaken");
  exit();
 }
 createUser($connection,$email,$name,$pass);
 header("Location: ../pages/signup.php?error=none");
 exit();
}
?>
