<?php
if(isset($_POST["submit"]))
{
 $email=$_POST["email"];
 $name=$_POST["name"];
 $pass=$_POST["pass"];
 $passRepeat=$_POST["passRepeat"];

 require_once '../include/db.php';
 require_once '../include/functions.php';
 session_start();

 $ID=$_SESSION["userid"];

 if(emptyInputSignup($email,$name,$pass,$passRepeat) !== false)
 {
  header("Location: ../pages/editProfile.php?error=emptyInput");
  exit();
 }
 if(invalidEmail($email) !== false)
 {
  header("Location: ../pages/editProfile.php?error=invalidEmail");
  exit();
 }
 if(invalidUsername($name) !== false)
 {
  header("Location: ../pages/editProfile.php?error=invalidUsername");
  exit();
 }
 if(passMatch($pass,$passRepeat) !== false)
 {
  header("Location: ../pages/editProfile.php?error=passwordsDoNotMatch");
  exit();
 }
 if(nameExists($connection,$name) !== false)
 {
  header("Location: ../pages/editProfile.php?error=usernameTaken");
  exit();
 }
 if(emailExists($connection,$email) !== false)
 {
  header("Location: ../pages/editProfile.php?error=emailTaken");
  exit();
 }
 changeUser($connection,$ID,$email,$name,$pass);
 header("Location: ../pages/editProfile.php?error=none");
 exit();
}
?>
