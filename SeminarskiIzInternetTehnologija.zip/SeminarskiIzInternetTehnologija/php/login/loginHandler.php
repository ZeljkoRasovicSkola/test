<?php
if(isset($_POST["submit"]))
{
 $name=$_POST["name"];
 $pass=$_POST["pass"];

 require_once '../include/db.php';
 require_once '../include/functions.php';

 if(emptyInputLogin($name,$pass) !== false)
 {
  header("Location: ../pages/login.php?error=emptyInputLogin");
  exit();
 }
 
 loginUser($connection,$name,$pass);
}
else
{
 header("Location: ../pages/login.php?error=none");
 exit();
}
?>
