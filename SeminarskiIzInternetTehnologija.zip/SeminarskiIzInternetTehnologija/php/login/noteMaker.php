<?php
if(isset($_POST["submit"]))
{
 $heading=$_POST["heading"];
 $text=$_POST["text"];

 require_once '../include/db.php';
 require_once '../include/functions.php';
 session_start();

 $ID=$_SESSION["userid"];

 if(emptyInputNote($heading,$text) !== false)
 {
  header("Location: ../pages/newNote.php?error=emptyInput");
  exit();
 }
 if(invalidHeading($heading) !== false)
 {
  header("Location: ../pages/newNote.php?error=invalidHeading");
  exit();
 }
 if(headingExists($connection,$heading) !== false)
 {
  header("Location: ../pages/newNote.php?error=headingTaken");
  exit();
 }
 createNote($connection,$ID,$heading,$text);
 header("Location: ../pages/newNote.php?error=none");
 exit();
}
?>
