<?php

function emptyInputSignup($email,$name,$pass,$passRepeat)
{
 $result;
 
 if(empty($email) || empty($name) || empty($pass) || empty($passRepeat))
  $result=true;
 else
  $result=false;
 
 return $result;
}

function invalidEmail($email)
{
 $result;
 
 if(!(filter_var($email,FILTER_VALIDATE_EMAIL)))
  $result=true;
 else
  $result=false;

 return $result;
}

function invalidUsername($name)
{
 $result;
 
 if(!(preg_match("/^[a-zA-Z0-9]*$/",$name)))
  $result=true;
 else
  $result=false;
 
 return $result;
}

function passMatch($pass,$passRepeat)
{
 $result;

 if($pass!==$passRepeat)
  $result=true;
 else
  $result=false;
 
 return $result;
}

function nameExists($connection,$name)
{
 $sql="SELECT * FROM Users WHERE Username=?;";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/signup.php?error=usernameTaken");
  exit();
 }

 mysqli_stmt_bind_param($stmt,"s",$name);
 mysqli_stmt_execute($stmt);

 $resultData=mysqli_stmt_get_result($stmt);

 if($row=mysqli_fetch_assoc($resultData))
  return $row;
 else
 {
  $result=false;
  return $result;
 }

 mysqli_stmt_close($stmt);
}

function emailExists($connection,$email)
{
 $sql="SELECT * FROM Users WHERE Email=?;";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/signup.php?error=emailTaken");
  exit();
 }

 mysqli_stmt_bind_param($stmt,"s",$email);
 mysqli_stmt_execute($stmt);

 $resultData=mysqli_stmt_get_result($stmt);

 if($row=mysqli_fetch_assoc($resultData))
  return $row;
 else
 {
  $result=false;
  return $result;
 }

 mysqli_stmt_close($stmt);
}

function createUser($connection,$email,$name,$pass)
{
 $sql="INSERT INTO Users(Email,Username,Password) VALUES (?,?,?);";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/signup.php?error=stmtfailed");
  exit();
 }

 $hashedPass=password_hash($pass,PASSWORD_DEFAULT);
 mysqli_stmt_bind_param($stmt,"sss",$email,$name,$hashedPass);
 mysqli_stmt_execute($stmt);
 mysqli_stmt_close($stmt);
}

function emptyInputLogin($name,$pass)
{
 $result;
 
 if(empty($name) || empty($pass))
  $result=true;
 else
  $result=false;
 
 return $result;
}

function nameExistsLogin($connection,$name,$email)
{
 $sql="SELECT * FROM Users WHERE Username=? OR Email=?;";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/signup.php?error=usernameTaken");
  exit();
 }

 mysqli_stmt_bind_param($stmt,"ss",$name,$email);
 mysqli_stmt_execute($stmt);

 $resultData=mysqli_stmt_get_result($stmt);

 if($row=mysqli_fetch_assoc($resultData))
  return $row;
 else
 {
  $result=false;
  return $result;
 }

 mysqli_stmt_close($stmt);
}

function loginUser($connection,$name,$pass)
{
 $nameExists=nameExistsLogin($connection,$name,$name);

 if($nameExists===false)
 {
  header("Location: ../pages/login.php?error=wronglogin");
  exit();
 }

 $passHashed=$nameExists["Password"];
 $checkPass=password_verify($pass,$passHashed);

 if($checkPass===false)
 {
  header("Location: ../pages/login.php?error=wronglogin");
  exit();
 }
 else if($checkPass===true)
 {
  session_start();
  $_SESSION["userid"]=$nameExists["UserID"];
  $_SESSION["username"]=$nameExists["Username"];
  
  header("Location: ../pages/home.php");
  exit();
 }
}

function emptyInputNote($heading,$text)
{
 $result;
 
 if(empty($heading) || empty($text))
  $result=true;
 else
  $result=false;
 
 return $result;
}

function invalidHeading($heading)
{
 $result;
 
 if(!(preg_match("/^[a-zA-Z0-9]*$/",$heading)))
  $result=true;
 else
  $result=false;
 
 return $result;
}

function headingExists($connection,$heading)
{
 $sql="SELECT * FROM Notes WHERE Heading=?;";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/newNote.php?error=headingTaken");
  exit();
 }

 mysqli_stmt_bind_param($stmt,"s",$heading);
 mysqli_stmt_execute($stmt);

 $resultData=mysqli_stmt_get_result($stmt);

 if($row=mysqli_fetch_assoc($resultData))
  return $row;
 else
 {
  $result=false;
  return $result;
 }

 mysqli_stmt_close($stmt);
}

function createNote($connection,$ID,$heading,$text)
{
 $sql="INSERT INTO Notes(UserID,Heading,NoteText) VALUES ('$ID',?,?);";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/newNote.php?error=stmtfailed");
  exit();
 }
 mysqli_stmt_bind_param($stmt,"ss",$heading,$text);
 mysqli_stmt_execute($stmt);
 mysqli_stmt_close($stmt);
}

function deleteNote($connection,$ID,$heading)
{
 $sql="DELETE FROM Notes WHERE UserID='$ID' AND Heading=?;";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/deleteNote.php?error=stmtfailed");
  exit();
 }

 mysqli_stmt_bind_param($stmt,"s",$heading);
 mysqli_stmt_execute($stmt);
 mysqli_stmt_close($stmt);
}

function updateNote($connection,$ID,$heading,$text)
{
 $sql="UPDATE Notes SET NoteText=? WHERE UserID='$ID' AND Heading=?;";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/deleteNote.php?error=stmtfailed");
  exit();
 }

 mysqli_stmt_bind_param($stmt,"ss",$text,$heading);
 mysqli_stmt_execute($stmt);
 mysqli_stmt_close($stmt);
}

function changeUser($connection,$ID,$email,$name,$pass)
{
 $sql="UPDATE Users SET Email=?, Username=?, Password=? WHERE UserID='$ID';";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/editProfile.php?error=stmtfailed");
  exit();
 }

 $hashedPass=password_hash($pass,PASSWORD_DEFAULT);
 mysqli_stmt_bind_param($stmt,"sss",$email,$name,$hashedPass);
 mysqli_stmt_execute($stmt);
 mysqli_stmt_close($stmt);
}

function deleteAllNotes($connection,$ID)
{
 $sql="DELETE FROM Notes WHERE UserID='$ID';";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/deleteNote.php?error=stmtfailed");
  exit();
 }
 mysqli_stmt_execute($stmt);
 mysqli_stmt_close($stmt);
}

function deleteUser($connection,$ID)
{
 $sql="DELETE FROM Users WHERE UserID='$ID';";
 $stmt=mysqli_stmt_init($connection);

 if(!(mysqli_stmt_prepare($stmt,$sql)))
 {
  header("Location: ../pages/editProfile.php?error=stmtfailed");
  exit();
 }
 mysqli_stmt_execute($stmt);
 mysqli_stmt_close($stmt);
}
?>
