<?php
 session_start();
 include 'db.php'
?>
<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="robots" content="noindex,nofollow,noimageindex,nosnippet,noarchive,notranslate">
  <meta name="author" content="Zeljko Rasovic">
  <meta name="description" content="Web notes">
  <meta name="keywords" content="Web notes">
  <title>Web notes</title>
  <link rel="icon" type="image/x-icon" href="../../img/list.svg">
  <link type="text/css" rel="stylesheet" media="screen" href="../../css/styleScreen.css">
  <link type="text/css" rel="stylesheet" media="print" href="../../css/stylePrint.css">
 </head>
