   <nav>
    <a href="home.php" class="navLinks">Home</a>
    <a href="aboutUs.php" class="navLinks">About Us</a>
    <a href="contactUs.php" class="navLinks">Contact Us</a>
    <a href="products.php" class="navLinks">Products</a>
    <?php
     if(isset($_SESSION["username"]))
     {
      echo'<form method="POST" action="search.php">';
      echo' <span id="searchBar">';
      echo'  <input type="text" name="searchText" "placeholder="Search">';
      echo'  <label for="searchButton"><img src="../../img/searchBlack.svg" alt="Search icon"></label>';
      echo'  <input type="submit" name="search" id="searchButton" style="display:none;">';
      echo' </span>';
      echo'</form>';
     }
     if(isset($_SESSION["username"]))
      echo'<a href="profile.php" class="navLinks">Profile</a>';
     else
      echo'<a href="login.php" class="navLinks">Login</a>';
    ?>
   </nav>
