<?php
 include_once '../include/head.php';
?>
 <body>
  <main>
   <section>
    <h2>Login</h2>
    <form method="POST" action="../login/loginHandler.php">
     <input type="text" name="name" placeholder="Username/Email">
     <br>
     <br>
     <input type="password" name="pass" placeholder="Password">
     <br>
     <br>
     <input type="submit" name="submit" value="Log In">
    </form>
    <br>
    <br>
    <a href="signup.php" class="navLinks">Sign up</a>
   </section>
   <section>
    <br>
    <br>
    <?php
    if(isset($_GET["error"]))
    {
     if($_GET["error"]=="emptyInputLogin")
      echo"<p>Fill in all fields!</p>";
     else if($_GET["error"]=="wronglogin")
      echo"<p>You entered wrong username/email or password!</p>";
    }
    ?>
   </section>
  </main>
 </body>
</html>
