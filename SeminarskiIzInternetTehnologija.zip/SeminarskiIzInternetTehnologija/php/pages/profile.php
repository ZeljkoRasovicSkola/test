<?php
 include_once '../include/head.php'
?>
 <body>
  <header>
  <?php
   include_once '../include/nav.php'
  ?>
  </header>
  <main>
   <section>
    <h2>Profile</h2>
    <?php
     if(isset($_SESSION["username"]))
     {
      echo'<p>Welcome '.$_SESSION["username"].'</p><br>';
     }
    ?>
    <a href="editProfile.php" class="navLinks">Edit profile</a>
    <br>
    <br>
    <br>
    <form method="POST" action="../login/logout.php">
     <input type="submit" name="logout" value="Logout">
    </form>
    <br>
    <form method="POST" action="../login/deleteProfile.php">
     <input type="submit" name="delete" value="Delete profile">
    </form>
    <br>
   </section>
  </main>
 </body>
</html>
