<?php
 include_once '../include/head.php'
?>
 <body>
  <header>
  <?php
   include_once '../include/nav.php'
  ?>
  </header>
  <main>
   <section>
    <h2>New note</h2>
    <p>Fill all the fields</p>
    <form method="POST" action="../login/noteMaker.php">
     <input type="text" name="heading" placeholder="Heading">
     <br>
     <br>
     <textarea name="text" placeholder="Note text"></textarea>
     <br>
     <br>
     <input type="submit" name="submit" value="Make note">
    </form>
   </section>
   <section>
    <br>
    <?php
    if(isset($_GET["error"]))
    {
     if($_GET["error"]=="emptyInput")
      echo"<p>Fill in all fields!</p>";
     else if($_GET["error"]=="invalidHeading")
      echo"<p>Choose a proper heading!</p>";
     else if($_GET["error"]=="headingTaken")
      echo"<p>Heading is already taken!</p>";
     else if($_GET["error"]=="stmtfailed")
      echo"<p>Something went wrong, try again!</p>";
     else if($_GET["error"]=="none")
      echo"<p>You have made note!</p>";
    }
    ?>
   </section>
  </main>
 </body>
</html>
