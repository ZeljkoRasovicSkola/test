<?php
 include_once '../include/head.php'
?>
 <body>
  <header>
  <?php
   include_once '../include/nav.php'
  ?>
  </header>
  <main>
   <section>
    <h2>Contact Us</h2>
    <p>Send e-mail</p>
    <form method="POST" action="../login/emailHandler.php">
     <input type="text" name="name" placeholder="Full name">
     <br>
     <br>
     <input type="email" name="mail" placeholder="Your e-mail">
     <br>
     <br>
     <input type="text" name="subject" placeholder="Subject">
     <br>
     <br>
     <textarea name="message" placeholder="Message"></textarea>
     <br>
     <br>
     <input type="submit" name="submit" value="Send mail">
    </form>
   </section>
  </main>
 </body>
</html>
