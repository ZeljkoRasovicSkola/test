<?php
 include_once '../include/head.php'
?>
 <body>
  <header>
  <?php
   include_once '../include/nav.php'
  ?>
  </header>
  <main>
   <section>
    <h2>Home</h2>
    <?php
     if(isset($_SESSION["username"]))
     {
      echo'<h3>All notes:</h3>';
      echo'<div class="notes">';
      $sql="SELECT * FROM Notes WHERE UserID='$_SESSION[userid]';";
      $result=mysqli_query($connection,$sql);
      $queryResults=mysqli_num_rows($result);

      if($queryResults>0)
      {
       while($row=mysqli_fetch_assoc($result))
       {
        echo' <div class="note">';
        echo'  <h4>'.$row["Heading"].'</h4>';
        echo'  <p>'.$row["NoteText"].'</p>';
        echo'  <p>'.$row["DateCreated"].'</p>';
        echo' </div>';
       }
        echo'<hr>';
      }
      echo'</div><br><br>';
      echo'<a href="newNote.php" class="navLinks">New note</a>';
      echo'<a href="updateNote.php" class="navLinks">Update note</a>';
      echo'<a href="deleteNote.php" class="navLinks">Delete note</a>';
     }
     else
     {
      echo'<p>Welcome to web notes</p>';
     }
    ?>
   </section>
  </main>
 </body>
</html>
