<?php
 include_once '../include/head.php'
?>
 <body>
  <header>
  <?php
   include_once '../include/nav.php'
  ?>
  </header>
  <main>
   <section>
    <h2>Edit profile</h2>
    <form method="POST" action="../login/changeAccHandler.php">
     <input type="email" name="email" placeholder="E-mail">
     <br>
     <br>
     <input type="text" name="name" placeholder="Username">
     <br>
     <br>
     <input type="password" name="pass" placeholder="Password">
     <br>
     <br>
     <input type="password" name="passRepeat" placeholder="Repeat password">
     <br>
     <br>
     <input type="submit" name="submit" value="Change">
    </form>
   </section>
   <section>
    <br>
    <?php
    if(isset($_GET["error"]))
    {
     if($_GET["error"]=="emptyInput")
      echo"<p>Fill in all fields!</p>";
     else if($_GET["error"]=="invalidEmail")
      echo"<p>Choose a proper email!</p>";
     else if($_GET["error"]=="invalidUsername")
      echo"<p>Choose a proper username!</p>";
     else if($_GET["error"]=="passwordsDoNotMatch")
      echo"<p>Passwords do not match!</p>";
     else if($_GET["error"]=="stmtfailed")
      echo"<p>Something went wrong, try again!</p>";
     else if($_GET["error"]=="usernameTaken")
      echo"<p>Username is already taken!</p>";
     else if($_GET["error"]=="emailTaken")
      echo"<p>Email is already taken!</p>";
     else if($_GET["error"]=="none")
      echo"<p>You have changed your profile!</p>";
    }
    ?>
   </section>
  </main>
 </body>
</html>
