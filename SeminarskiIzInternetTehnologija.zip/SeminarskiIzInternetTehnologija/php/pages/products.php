<?php
 include_once '../include/head.php'
?>
 <body>
  <header>
  <?php
   include_once '../include/nav.php'
  ?>
  </header>
  <main>
   <section>
    <h2>Products</h2>
    <p>We do not have them.</p>
   </section>
  </main>
 </body>
</html>
