<?php
if(isset($_POST["delete"]))
{
 require_once '../include/db.php';
 require_once '../include/functions.php';
 session_start();

 $ID=$_SESSION["userid"];
 
 deleteAllNotes($ID);
 deleteUser($connection,$ID);
 header("Location: ../pages/login.php");
 exit();
}
?>
