<?php
 include_once '../include/head.php'
?>
 <body>
  <header>
  <?php
   include_once '../include/nav.php'
  ?>
  </header>
  <main>
   <section>
    <h2>Search results</h2>
    <?php
     if(isset($_POST["search"]))
     {
      $search=mysqli_real_escape_string($connection,$_POST["searchText"]);
      $sql="SELECT * FROM Notes WHERE UserID='$_SESSION[userid]' AND (Heading LIKE '%$search%' OR NoteText LIKE '%$search%' OR DateCreated LIKE '%$search%');";
      $result=mysqli_query($connection,$sql);
      $queryResult=mysqli_num_rows($result);

      echo'There are '.$queryResult.' results.'.'<br><br>';
      echo'<div class="notes">';

      if($queryResult>0)
      {
       while($row=mysqli_fetch_assoc($result))
       {
        echo' <a href="article.php?heading='.$row["Heading"].'&date='.$row["DateCreated"].'>';
        echo'  <div class="note">';
        echo'   <h4>'.$row["Heading"].'</h4>';
        echo'   <p>'.$row["NoteText"].'</p>';
        echo'   <p>'.$row["DateCreated"].'</p>';
        echo'  </div>';
        echo' </a>';
       }
      }
       echo'</div>';
     }
     else
     {
      echo'<p>There are no results matching your search!</p>';
     }
    ?>
   </section>
  </main>
 </body>
</html>
