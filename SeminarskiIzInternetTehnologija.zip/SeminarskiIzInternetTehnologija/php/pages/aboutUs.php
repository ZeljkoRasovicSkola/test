<?php
 include_once '../include/head.php'
?>
 <body>
  <header>
  <?php
   include_once '../include/nav.php'
  ?>
  </header>
  <main>
   <section>
    <h2>About Us</h2>
    <p>We are a company.</p>
   </section>
  </main>
 </body>
</html>
