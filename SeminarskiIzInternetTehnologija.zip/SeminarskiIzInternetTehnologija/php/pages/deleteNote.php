<?php
 include_once '../include/head.php'
?>
 <body>
  <header>
  <?php
   include_once '../include/nav.php'
  ?>
  </header>
  <main>
   <section>
    <h2>Delete note</h2>
    <p>Input the heading</p>
    <form method="POST" action="../login/noteDestroyer.php">
     <input type="text" name="heading" placeholder="Heading">
     <br>
     <br>
     <input type="submit" name="submit" value="Delete note">
    </form>
   </section>
   <section>
    <br>
    <?php
    if(isset($_GET["error"]))
    {
     if($_GET["error"]=="emptyInput")
      echo"<p>Fill in all fields!</p>";
     else if($_GET["error"]=="invalidHeading")
      echo"<p>Choose a proper heading!</p>";
     else if($_GET["error"]=="headingDoesNotExist")
      echo"<p>Heading does not exist!</p>";
     else if($_GET["error"]=="stmtfailed")
      echo"<p>Something went wrong, try again!</p>";
     else if($_GET["error"]=="none")
      echo"<p>You have deleted a note!</p>";
    }
    ?>
   </section>
  </main>
 </body>
</html>
